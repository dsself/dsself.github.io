#R version 4.2.1 (2022-06-23)
#Platform: x86_64-w64-mingw32/x64 (64-bit)
#Running under: Windows 10 x64 (build 19044)

library(dplyr) #version 1.0.9
library(readr) #version 2.1.2
library(stringr) #version 1.4.0


#descriptive DD####
dd <- read_csv("data/DD.csv") %>% 
  select(countryname, year, regime_cgv, democracy) %>% 
  group_by(countryname) %>% 
  mutate(fail = ifelse(lag(regime_cgv) != regime_cgv, 1, 0), number = cumsum(ifelse(is.na(fail), 0, fail)), number = number + 1)  %>% 
  group_by(countryname, number) %>% 
  filter(regime_cgv == 4 & democracy == 0) %>% 
  mutate(duration = length(number)) 

dd_count <- dd %>% 
  select(countryname, number) %>% 
  unique() %>% 
  nrow()

dd_duration <- dd %>% 
  ungroup() %>% 
  select(countryname, number, duration) %>%
  unique() %>% 
  mutate(avg = round(mean(duration), 2)) %>% 
  select(avg) %>%  unique()

dd <- cbind(dd_count, dd_duration) %>% 
  mutate(Dataset = "DD") %>% 
  select(Dataset, Count = dd_count, Duration = avg)

#descriptive GWF ####

gwf <- read_csv("data/gwf2010.csv") %>% 
  select(countryname, year, gwf_casename, gwf_regimetype, gwf_duration) %>% 
  filter(str_detect(gwf_regimetype, "military")) %>% 
  group_by(gwf_casename) %>% 
  mutate(duration = max(gwf_duration)) 

gwf_count <- gwf %>% 
  select(gwf_casename) %>% 
  unique() %>% 
  nrow()

gwf_duration <- gwf %>% 
  ungroup() %>% 
  select(gwf_casename, duration) %>%
  unique() %>% 
  mutate(avg = round(mean(duration), 2)) %>% 
  select(avg) %>%  unique()

gwf <- cbind(gwf_count, gwf_duration) %>% 
  mutate(Dataset = "GWF") %>% 
  select(Dataset, Count = gwf_count, Duration = avg)

#descriptive WTH####
wth <- read_csv("data/ARD.csv") %>% 
  select(country, year, regimeny) %>% 
  group_by(country) %>% 
  mutate(fail = ifelse(lag(regimeny) != regimeny, 1, 0), number = cumsum(ifelse(is.na(fail), 0, fail)), number = number + 1)  %>% 
  group_by(country, number) %>% 
  filter(str_detect(regimeny, "military")) %>% 
  mutate(duration = length(number)) 

wth_count <- wth %>% 
  select(country, number) %>% 
  unique() %>% 
  nrow()

wth_duration <- wth %>% 
  ungroup() %>% 
  select(country, number, duration) %>%
  unique() %>% 
  mutate(avg = round(mean(duration), 2)) %>% 
  select(avg) %>%  unique()

wth <- cbind(wth_count, wth_duration) %>% 
  mutate(Dataset = "WTH") %>% 
  select(Dataset, Count = wth_count, Duration = avg)
#descriptive PAR####
par <- read_csv("data/Svolik Clean.csv") %>% 
  select(countryname, year, par_regime, par_military) %>%
  group_by(countryname) %>% 
  mutate(par_military = ifelse(is.na(par_military), par_regime, par_military)) %>% 
  mutate(fail = ifelse(lag(par_military) != par_military, 1, 0), number = cumsum(ifelse(is.na(fail), 0, fail)), number = number + 1)  %>% 
  group_by(countryname, number) %>% 
  #it looks like the number only accounts for auto to demo, need to account for changes in form of military 
  filter(par_regime == "dictatorship" & par_military %in% c("corporate", "indirect", "personal")) %>% 
  mutate(duration = length(number)) 

par_count <- par %>% 
  select(countryname, number) %>% 
  unique() %>% 
  nrow()

par_duration <- par %>% 
  ungroup() %>% 
  select(countryname, number, duration) %>%
  unique() %>% 
  mutate(avg = round(mean(duration), 2)) %>% 
  select(avg) %>%  unique()

par <- cbind(par_count, par_duration) %>% 
  mutate(Dataset = "PAR") %>% 
  select(Dataset, Count = par_count, Duration = avg)

#values for Table 1 #last column is the number of observations from the main models
all <- rbind(gwf, par, dd, wth) %>% 
  mutate(Duration = round(Duration, 2))


