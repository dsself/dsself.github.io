Files

**datafiles**
all_regimes.csv 
Original coding of each regime transition where antecedent regime is military. 

ARD.csv - Authoritarian Regimes dataset
https://sites.google.com/site/authoritarianregimedataset/

DD.csv - Democracy and Dictatorship
https://sites.google.com/site/joseantoniocheibub/datasets/dd

Svolik Clean.csv
https://campuspress.yale.edu/svolik/the-politics-of-authoritarian-rule/

gwf2010.csv
Geddes Wright and Frantz 2010 data
https://sites.psu.edu/dictators/

panel.csv
Collection of datasets widely used in comparative politics

vdem_party10.rds
R version of V-Dem party data version 10

dd_fa_pi.csv, gwf_fa_pi.csv, svolik_fa_pi.csv, wth_fa_pi.csv
Each produced with incumbent_pi_fa.R script 
Uses factor analysis to produce Party Institutionalization variable 

dd_fa_strength.csv, gwf_fa_strength.csv, svolik_fa_strength.csv, wth_fa_strength.csv
Each produced with incumbent_pi_fa.R script 
Uses factor analysis to produce Party Institutionalization variable 

dd_irt.csv, gwf_irt.csv, svolik_irt.csv, wth_irt.csv
Each produced with irt_models.R script. 
User needs to unload packages associated with library(ltm) after use if running any other script in the replication files. 

**Scripts**
Figure1.R

Script to produce Figure 1 of main text


Table1.R

Script to produce Table 1 of the main text. Final column is a count of cases from Table4.R and Table5.R

main_models.R
Produces coefficient plots for Figures 3-7 in main text

#The following scripts produce data which are then used in models for the primary text and which can be reproduced using main_models.R. 
irt_models.R
Produces primary dependent variable of bounded democratization used in all models. Also produces values for Table 3 in the main text. 

incumbent_pi_fa.R
Produces independent variable of Party Institutionalization

incumbent_strength_fa.R
Produces independent variable of Party Strength


appendix_a.R
Replication code for all figures in Appendix A.

appendix_b.R
Replication code for tables in Appendix B which provide full results of models used in the main text. 

appendix_c.R
Replication code for figures in Appendix C.  

appendix_d.R
Replication code for figures in Appendix D.  