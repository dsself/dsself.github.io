#appendix tables for figure 6
#just do auto_pi, then add controls

library(tidyverse)
library(survival)
library(broom)
library(stargazer)

df <- read_csv("data/panel.csv") %>% 
  select(countryname, cowcode, year, v2xps_party, starts_with("v2ps"), starts_with("gwf"), auto_pi, oppo_auto, lgmilex_cap, lag_milexp, firstmil, seizure, seizure_rebel, larea, govstruct, lgupop, e_migdppcln, e_Total_Resources_Income_PC, latent_personalism) %>% 
  filter(gwf_duration < 100) %>% 
  mutate(auto_pi = ifelse(v2xps_party == 0, 0, auto_pi)) %>% 
  mutate(cowcode = as.character(cowcode)) %>% 
  filter(gwf_regime %in% c("Military", "Personal", "Party", "Monarchy")) %>% 
  mutate(gwf_regime = fct_relevel(gwf_regime, "Monarchy", "Party", "Personal", "Military")) %>% 
  rename(party = gwf_party, mil = gwf_military, personal = gwf_personal, monarchy = gwf_monarchy) %>% 
  select(countryname, year, gwf_regime, gwf_duration, gwf_fail, party, personal, mil, monarchy, auto_pi, oppo_auto, lgmilex_cap, lag_milexp, firstmil, seizure, seizure_rebel, larea, govstruct, lgupop, e_migdppcln, e_Total_Resources_Income_PC, latent_personalism) %>% 
  mutate(percentile = ntile(latent_personalism, 100)) %>% 
  mutate(qtile = ifelse(percentile <= 25, "25th",
                        ifelse(percentile >= 75, "75th", "50th"))) %>% 
  mutate(revolution = ifelse(seizure == "rebel", 1, 0))

cox1 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime*auto_pi, data = df)
cox2 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime*auto_pi + oppo_auto + lag_milexp +  lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea, data = df)
cox3 <- coxph(Surv(gwf_duration, gwf_fail) ~ qtile*auto_pi, data = df)
cox4 <- coxph(Surv(gwf_duration, gwf_fail) ~ qtile*auto_pi + oppo_auto + lag_milexp +  lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution +  larea, data = df)

stderr1 <- summary(cox1)$coefficients[,3]*exp(summary(cox1)$coefficients[,3])
stderr2 <- summary(cox2)$coefficients[,3]*exp(summary(cox2)$coefficients[,3])

p1 <- summary(cox1)$coefficients[,5]
p2 <- summary(cox2)$coefficients[,5]
p3 <- summary(cox3)$coefficients[,5]
p4 <- summary(cox4)$coefficients[,5]

pvalues <- list(p1, p2, p3, p4)

semult <- function(x) (x * exp(x))

stargazer(cox1, cox2, cox3, cox4,
          apply.coef = exp, apply.se = semult, digits = 2, dep.var.labels = "Regime Failure",
          omit = c("oppo_auto", "lag_milexp", "lgupop", "e_migdppcln", "revolution", "e_Total_Resources_Income_PC", "latent_personalism", "larea"), 
          keep.stat = c("n", "rsq", "max.rsq"), p.auto = FALSE, p = pvalues, 
          covariate.labels = c("Party", "Personal", "Military", "50th", "75th", "APS", "Party*APS", "Personal*APS", "Military*APS", "50th*APS", "75th*APS"),
          add.lines = list(c("Non-regime Controls", "No", "Yes", "No", "Yes")), 
          column.labels = c("Regime Interaction", "Personalism Interaction"), column.separate = c(2, 2))

