library(tidyverse)
library(survival)
library(broom)
library(stargazer)
library(margins)
library(prediction)

load("data/weibullstderror.Rdta")

#####Weibull replication Table 1####
d1 <- read_csv("data/panel.csv") %>% 
  select(countryname, cowcode, year, v2xps_party, starts_with("v2ps"), auto_pi, gwf_regime, gwf_regimetype, gwf_duration, gwf_fail, oppo_auto, lgmilex_cap, lag_milexp, firstmil, seizure, seizure_rebel, larea, govstruct, lgupop, e_migdppcln, e_Total_Resources_Income_PC, latent_personalism) %>% 
  filter(gwf_duration < 100) %>% 
  mutate(auto_pi = ifelse(v2xps_party == 0, 0, auto_pi)) %>% 
  mutate(cowcode = as.character(cowcode)) %>% 
  filter(gwf_regime %in% c("Military", "Personal", "Party", "Monarchy"))  %>% 
  mutate(gwf_regime = factor(gwf_regime, levels = c("Personal", "Party", "Military", "Monarchy"))) %>% 
  mutate(gwf_regimetype = factor(gwf_regimetype, levels = c("personal", "military", "military-personal", "party-military", "party", 
                                                            "party-military-personal", "party-personal", "monarchy"))) %>% 
  mutate(revolution = ifelse(seizure == "rebel", 1, 0)) 

d2 <- d1 %>% 
  filter(gwf_regime != "Monarchy")
#with monarchies
w1 <- survreg(Surv(gwf_duration, gwf_fail)~ auto_pi + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w2 <- survreg(Surv(gwf_duration, gwf_fail)~ auto_pi + oppo_auto + lag_milexp + lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w3 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime  + auto_pi + oppo_auto + lag_milexp + lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w4 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regimetype  + auto_pi + oppo_auto + lag_milexp + lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
#without
w5 <- survreg(Surv(gwf_duration, gwf_fail)~ auto_pi + factor(countryname) + factor(year), data= d2, na.action=na.omit, dist="weibull")
#oppo_auto w/time fe breaks this one for some reason
w6 <- survreg(Surv(gwf_duration, gwf_fail)~ auto_pi + oppo_auto + lag_milexp + lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea + factor(countryname), data = d2, na.action=na.omit, dist="weibull")
w7 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime  + auto_pi + oppo_auto + lag_milexp + lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea + factor(countryname) + factor(year), data = d2, na.action=na.omit, dist="weibull")
w8 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regimetype  + auto_pi + oppo_auto + lag_milexp + lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea + factor(countryname) + factor(year), data = d2, na.action=na.omit, dist="weibull")

tidy_up = function(x, y) (tidy(x) %>% 
    mutate(estimate = exp(-estimate/x$scale)) %>% 
    filter(term != "Log(scale)", term != "(Intercept)") %>% 
    mutate(std.error = weibullstderror(x)) %>% 
    filter(term == "auto_pi") %>% 
    mutate_if(is.numeric, round, 3) %>% 
    mutate(n = summary(x)$n, model = y)) 

t1 <- tidy_up(w1, "one")
t2 <- tidy_up(w2, "two")
t3 <- tidy_up(w3, "three")
t4 <- tidy_up(w4, "four")
t5 <- tidy_up(w5, "five")
t6 <- tidy_up(w6, "six")
t7 <- tidy_up(w7, "seven")
t8 <- tidy_up(w8, "eight")

all <- rbind(t1, t2, t3, t4, t5, t6, t7, t8)

##Table 3 replication with fixed effects #####
w1 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime + v2psorgs   + oppo_auto + lag_milexp + lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w2 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime + v2psprbrch + oppo_auto + lag_milexp + lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w3 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime + v2pscnslnl + oppo_auto + lag_milexp + lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w4 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime + v2psprlnks + oppo_auto + lag_milexp + lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w5 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime + v2pssunpar + oppo_auto + lag_milexp + lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w6 <- survreg(Surv(gwf_duration, gwf_fail)~ v2psorgs + v2psprbrch + v2pscnslnl + v2psprlnks + v2pssunpar + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w7 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime + v2psorgs + v2psprbrch + v2pscnslnl + v2psprlnks + v2pssunpar + oppo_auto + lag_milexp + lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w8 <- survreg(Surv(gwf_duration, gwf_fail)~ v2psorgs + v2psprbrch + v2pscnslnl + v2psprlnks + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w9 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime + v2psorgs + v2psprbrch + v2pscnslnl + v2psprlnks + oppo_auto + lag_milexp + lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")

tidy_up = function(x, y) (tidy(x) %>% 
                            mutate(estimate = exp(-estimate/x$scale)) %>% 
                            filter(term != "Log(scale)", term != "(Intercept)") %>% 
                            mutate(std.error = weibullstderror(x)) %>% 
                            filter(term %in% c("v2psorgs", "v2psprbrch", "v2pscnslnl", "v2psprlnks", "v2pssunpar")) %>% 
                            mutate_if(is.numeric, round, 3) %>% 
                            mutate(n = summary(x)$n, model = y)) 

t1 <- tidy_up(w1, "one")
t2 <- tidy_up(w2, "two")
t3 <- tidy_up(w3, "three")
t4 <- tidy_up(w4, "four")
t5 <- tidy_up(w5, "five")
t6 <- tidy_up(w6, "six")
t7 <- tidy_up(w7, "seven")
t8 <- tidy_up(w8, "eight")
t9 <- tidy_up(w9, "nine")

all <- rbind(t1, t2, t3, t4, t5, t6, t7, t8, t9) 

####Figure 6 Weibull####
library(tidyverse)
library(survival)
library(broom)
library(stargazer)
library(prediction)

df <- read_csv("data/panel.csv") %>% 
  select(countryname, cowcode, year, v2xps_party, starts_with("v2ps"), starts_with("gwf"), auto_pi, oppo_auto, lgmilex_cap, lag_milexp, firstmil, seizure, seizure_rebel, larea, govstruct, lgupop, e_migdppcln, e_Total_Resources_Income_PC, latent_personalism) %>% 
  filter(gwf_duration < 100) %>% 
  mutate(auto_pi = ifelse(v2xps_party == 0, 0, auto_pi)) %>% 
  mutate(cowcode = as.character(cowcode)) %>% 
  filter(gwf_regime %in% c("Military", "Personal", "Party", "Monarchy")) %>% 
  mutate(gwf_regime = fct_relevel(gwf_regime, "Monarchy", "Party", "Personal", "Military")) %>% 
  rename(party = gwf_party, mil = gwf_military, personal = gwf_personal, monarchy = gwf_monarchy) %>% 
  select(countryname, year, gwf_regime, gwf_duration, gwf_fail, party, personal, mil, monarchy, auto_pi, oppo_auto, lgmilex_cap, lag_milexp, firstmil, seizure, seizure_rebel, larea, govstruct, lgupop, e_migdppcln, e_Total_Resources_Income_PC, latent_personalism) %>% 
  mutate(percentile = ntile(latent_personalism, 100)) %>% 
  mutate(qtile = ifelse(percentile <= 25, "25th",
                        ifelse(percentile >= 75, "75th", "50th"))) %>% 
  na.omit()%>% 
  mutate(revolution = ifelse(seizure == "rebel", 1, 0))

m1 <- survreg(Surv(gwf_duration, gwf_fail) ~ gwf_regime*auto_pi + oppo_auto + lag_milexp +  lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea + factor(countryname) + factor(year), dist = "weibull", data = df)

p1 <- prediction(m1, type = "lp", at = list(gwf_regime = c("Party", "Military", "Personal"))) %>% 
  filter(gwf_regime != "Monarchy") %>% 
  select(gwf_regime, auto_pi, fitted, se.fitted)%>% 
  group_by(gwf_regime) %>% 
  mutate(lci = fitted - qnorm(0.975)*sd(fitted)/sqrt(n()), uci = fitted + qnorm(0.975)*sd(fitted)/sqrt(n())) %>% 
  group_by(gwf_regime, auto_pi) %>% 
  mutate(mean_fit = mean(fitted), mean_se = sqrt(sum(se.fitted^2))/sqrt(n()), mean_lci = mean(lci), mean_uci = mean(uci)) %>%   
  ungroup() %>% 
  select(gwf_regime, auto_pi, mean_fit, mean_se, mean_lci, mean_uci) %>% 
  distinct() %>% 
  filter(gwf_regime %in% c("Party", "Military", "Personal"), auto_pi <= .9 & auto_pi >=.3 & gwf_regime == "Personal" |
           auto_pi <= .9 & auto_pi >=.2 & gwf_regime == "Military" | auto_pi <= 1 & auto_pi >=.2 & gwf_regime == "Party")  

ggplot(p1, aes(x = auto_pi, y = mean_fit, color = gwf_regime)) +
  geom_smooth(method = "lm") +
  theme_bw() +
  theme(legend.position = "bottom") +
  ylab("Relative Probability of Surviving") +
  xlab("Authoritarian Party Strength") +
  scale_color_grey(start = 0.0, end = 0.7, name = "Regime") 

ggsave(filename =  "figures/a10.jpg", dpi = 500, width = 5, height = 5)

m1 <- survreg(Surv(gwf_duration, gwf_fail) ~ qtile*auto_pi + oppo_auto + lag_milexp +  lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution +  larea + factor(countryname) + factor(year), dist = "weibull", data = df)

p1 <- prediction(m1, type = "lp", at = list(qtile = c("25th", "50th", "75th"))) %>% 
  filter(gwf_regime != "Monarchy") %>% 
  select(qtile, auto_pi, fitted, se.fitted)%>% 
  group_by(qtile) %>% 
  mutate(lci = fitted - qnorm(0.975)*sd(fitted)/sqrt(n()), uci = fitted + qnorm(0.975)*sd(fitted)/sqrt(n())) %>% 
  group_by(qtile, auto_pi) %>% 
  mutate(mean_fit = mean(fitted), mean_se = sqrt(sum(se.fitted^2))/sqrt(n()), mean_lci = mean(lci), mean_uci = mean(uci)) %>%   
  ungroup() %>% 
  select(qtile, auto_pi, mean_fit, mean_se, mean_lci, mean_uci) %>% 
  distinct() #%>% 
#filter(gwf_regime %in% c("Party", "Military", "Personal"), auto_pi <= .9 & auto_pi >=.3 & gwf_regime == "Personal" |
#auto_pi <= .9 & auto_pi >=.2 & gwf_regime == "Military" | auto_pi <= 1 & auto_pi >=.2 & gwf_regime == "Party")  

ggplot(p1, aes(x = auto_pi, y = mean_fit, color = qtile)) +
  geom_smooth(method = "lm") +
  theme_bw() +
  theme(legend.position = "bottom") +
  ylab("Relative Probability of Surviving") +
  xlab("Authoritarian Party Strength") +
  scale_color_grey(start = 0.0, end = 0.7, name = "Personalism") 

ggsave(filename =  "figures/a11.jpg", dpi = 500, width = 5, height = 5)
