library(tidyverse)
library(survival)
library(broom)


d1 <- read_csv("data/panel.csv") %>% 
  filter(gwf_duration < 100)

km1 <- tidy(survfit(Surv(gwf_duration, gwf_fail) ~ gwf_regime, data = d1)) %>% 
  na.omit() %>% 
  mutate(Regime = ifelse(strata == "gwf_regime=Military", "Military", 
                         ifelse(strata == "gwf_regime=Monarchy", "Monarchy", 
                                ifelse(strata == "gwf_regime=Party", "Party", 
                                       ifelse(strata == "gwf_regime=Personal", "Personal", NA))))) 

ggplot(km1) +
  geom_line(aes(x = time, y = estimate, color = Regime, linetype = Regime)) +
  geom_ribbon(aes(x = time, y = estimate, ymin = conf.low, ymax = conf.high, fill = Regime), alpha = 0.2) +
  theme_bw() +
  scale_color_grey() +
  scale_fill_grey() +
  theme(legend.position="bottom") +
  ylab("Estimate") +
  xlab("Duration") +
  ylim(0.5, 1) +
  scale_linetype_manual(values=c("dotted", "solid", "dotdash", "longdash")) +
  guides(color=guide_legend(nrow=2,byrow=TRUE))

ggsave("figures/fig3.jpg", dpi = 500, width = 5, height = 5)
