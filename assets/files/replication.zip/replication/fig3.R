library(tidyver)

d1 <- read_csv("data/panel.csv") %>% 
  select(countryname, year, gwf_regimetype, auto_pi) %>% 
  filter(gwf_regimetype %in% c("military-personal", "party-military", "party-personal", "military", "personal", "party", "party-military-personal")) %>% 
  mutate(gwf_regimetype = ifelse(gwf_regimetype == "party-military-personal", "triple", gwf_regimetype)) %>% 
  mutate(gwf_regimetype = factor(gwf_regimetype, levels = c("party", "party-military", "party-personal", "triple",
                                                    "military-personal", "personal", "military"))) 

ggplot(d1) +
  geom_boxplot(aes(x = gwf_regimetype, y = auto_pi)) +
  theme_bw() +
  ylab("Autocratic Party Strength") +
  xlab("Regime Type") +
  scale_x_discrete(labels = c("Party", "Party-Military", "Party-Personal", "Triple-threat", "Military-Personal", "Personal", "Military")) +
  theme(axis.text.x=element_text(angle=30, vjust=.8, hjust=0.8))

ggsave("figures/fig3.jpg", dpi = 500)
