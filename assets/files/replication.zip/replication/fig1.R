library(tidyverse)
library(scales)

d1 <- read_csv("data/panel.csv") %>% 
  filter(gwf_duration < 100) %>% 
  select(countryname, cowcode, v2psbars_ord, v2lgbicam, gwf_regime, gwf_number) %>% 
  mutate(cowcode = as.character(cowcode)) %>% 
  filter(gwf_regime %in% c("Military", "Personal", "Party", "Monarchy")) %>% 
  mutate(Parties = ifelse(v2psbars_ord == 0, "No", "Yes"), 
         Parties = ifelse(v2lgbicam == 0, "No", Parties),
         Parties = ifelse(gwf_regime == "Party", "Yes", Parties),
         gwf_regime = fct_relevel(gwf_regime, "Party", "Personal", "Military")) %>% 
  unique() %>% 
  group_by(gwf_regime) %>% 
  count(Parties) %>% 
  mutate(p = n/sum(n)) %>% 
  ungroup() %>% 
  add_row(gwf_regime = "Party", Parties = "No", p = .01)

ggplot(data=d1,aes(x= gwf_regime, y = p, fill = Parties)) +
  geom_bar(position="dodge", stat="identity")  +
  theme_bw() +
  scale_fill_grey() +
  xlab("Regime Type") +
  ylab("Percentage") +
  theme(legend.position="bottom") +
  scale_y_continuous(labels=scales::percent) 

ggsave("figures/fig1.jpg", dpi = 500, width = 5, height = 5)
