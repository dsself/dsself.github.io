library(tidyverse)
library(survival)
library(broom)
library(stargazer)


d1 <- read_csv("data/panel.csv") %>% 
  select(countryname, cowcode, year, v2xps_party, starts_with("v2ps"), starts_with("auto"), gwf_regime, gwf_regimetype, gwf_duration, gwf_fail, oppo_auto, lgmilex_cap, lag_milexp, firstmil, seizure, seizure_rebel, larea, govstruct, lgupop, e_migdppcln, e_Total_Resources_Income_PC, latent_personalism) %>% 
  filter(gwf_duration < 100) %>%
  filter(gwf_regime %in% c("Military", "Party", "Personal")) %>% 
  #filter(gwf_regime %in% c("Military", "Personal", "Party", "Monarchy"))  %>% 
  mutate(gwf_regime = factor(gwf_regime, levels = c("Personal", "Party", "Military"))) %>% 
  mutate(auto_pi = ifelse(v2xps_party == 0, 0, auto_pi)) %>% 
  mutate(auto_pi_min = ifelse(v2xps_party == 0, 0, auto_pi_min)) %>% 
  mutate(auto_pim = ifelse(v2xps_party == 0, 0, auto_pim)) %>% 
  mutate(auto_pim_min = ifelse(v2xps_party == 0, 0, auto_pim_min)) %>% 
  mutate(auto_pifa = ifelse(v2xps_party == 0, 0, auto_pifa)) %>% 
  mutate(auto_pifa_min = ifelse(v2xps_party == 0, 0, auto_pifa_min)) %>% 
  mutate(revolution = ifelse(seizure == "rebel", 1, 0)) 


#with links
cox1 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime  + auto_pi + oppo_auto + lag_milexp +  lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea, data = d1)
cox2 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime  + auto_pim + oppo_auto + lag_milexp +  lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea, data = d1)
cox3 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime  + auto_pifa + oppo_auto + lag_milexp +  lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea, data = d1)
#without links
cox4 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime  + auto_pi_min + oppo_auto + lag_milexp +  lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea, data = d1)
cox5 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime  + auto_pim_min + oppo_auto + lag_milexp +  lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea, data = d1)
cox6 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime  + auto_pifa_min + oppo_auto + lag_milexp +  lgupop + e_migdppcln + e_Total_Resources_Income_PC + revolution + latent_personalism + larea, data = d1)

names(cox1$coefficients) <- c("gwf_regimeParty", "gwf_regimeMilitary", "APS", "oppo_auto", "lag_milexp", "lgupop", "e_migdppcln", "e_Total_Resources_Income_PC", "revolution", "latent_personalism", "larea")
names(cox2$coefficients) <- c("gwf_regimeParty", "gwf_regimeMilitary", "APS", "oppo_auto", "lag_milexp", "lgupop", "e_migdppcln", "e_Total_Resources_Income_PC", "revolution", "latent_personalism", "larea")
names(cox3$coefficients) <- c("gwf_regimeParty", "gwf_regimeMilitary", "APS", "oppo_auto", "lag_milexp", "lgupop", "e_migdppcln", "e_Total_Resources_Income_PC", "revolution", "latent_personalism", "larea")
names(cox4$coefficients) <- c("gwf_regimeParty", "gwf_regimeMilitary", "APS", "oppo_auto", "lag_milexp", "lgupop", "e_migdppcln", "e_Total_Resources_Income_PC", "revolution", "latent_personalism", "larea")
names(cox5$coefficients) <- c("gwf_regimeParty", "gwf_regimeMilitary", "APS", "oppo_auto", "lag_milexp", "lgupop", "e_migdppcln", "e_Total_Resources_Income_PC", "revolution", "latent_personalism", "larea")
names(cox6$coefficients) <- c("gwf_regimeParty", "gwf_regimeMilitary", "APS", "oppo_auto", "lag_milexp", "lgupop", "e_migdppcln", "e_Total_Resources_Income_PC", "revolution", "latent_personalism", "larea")

stderr1 <- summary(cox1)$coefficients[,3]*exp(summary(cox1)$coefficients[,3])
stderr2 <- summary(cox2)$coefficients[,3]*exp(summary(cox2)$coefficients[,3])
stderr3 <- summary(cox3)$coefficients[,3]*exp(summary(cox3)$coefficients[,3])
stderr4 <- summary(cox4)$coefficients[,3]*exp(summary(cox4)$coefficients[,3])
stderr5 <- summary(cox5)$coefficients[,3]*exp(summary(cox5)$coefficients[,3])
stderr6 <- summary(cox6)$coefficients[,3]*exp(summary(cox6)$coefficients[,3])

p1 <- summary(cox1)$coefficients[,5]
p2 <- summary(cox2)$coefficients[,5]
p3 <- summary(cox3)$coefficients[,5]
p4 <- summary(cox4)$coefficients[,5]
p5 <- summary(cox5)$coefficients[,5]
p6 <- summary(cox6)$coefficients[,5]


pvalues <- list(p1, p2, p3, p4, p5, p6)

semult <- function(x) (x * exp(x))

stargazer(cox1, cox2, cox3, cox4, cox5, cox6, 
          apply.coef = exp, apply.se = semult, digits = 2, dep.var.labels = "Regime Failure",
          omit = c("oppo_auto", "lgmilex_cap", "lgpec", "lgupop", "e_migdppcln", "e_Total_Resources_Income_PC", 
                   "gwf_regimeParty", "gwf_regimeMilitary", "revolution", "lag_milexp", "latent_personalism", "larea"), 
          keep.stat = c("n", "rsq", "max.rsq"), p.auto = FALSE, p = pvalues,
          column.labels = c("With Social Linkages", "Without Social Linkages"),
          covariate.labels = c("APS"),
          column.separate = c(3, 3), add.lines = list(
                                                      c("Index", "Additive", "Multiplicative", "FA", "Additive", "Multiplicative", "FA"),
                                                      c("Non-regime Controls", "Yes", "Yes", "Yes", "Yes", "Yes", "Yes"),
                                                      c("Regime Controls", "Yes", "Yes", "Yes", "Yes", "Yes", "Yes")))

