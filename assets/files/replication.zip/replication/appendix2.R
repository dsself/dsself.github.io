library(tidyverse)
library(survival)
library(broom)
library(stargazer)

load("data/weibullstderror.Rdta")

#####Weibull replication Table 1####
d1 <- read_csv("data/panel.csv") %>% 
  select(countryname, cowcode, year, v2xps_party, starts_with("v2ps"), gwf_regime, gwf_regimetype, gwf_duration, gwf_fail, auto_pi, oppo_auto, cpi, milex, milper, lgmilex_cap, irst, lgpec, tpop, lgupop, cinc, e_migdppcln,  e_Total_Resources_Income_PC) %>% 
  filter(gwf_duration < 100) %>% 
  mutate(auto_pi = ifelse(v2xps_party == 0, 0, auto_pi)) %>% 
  mutate(cowcode = as.character(cowcode)) %>% 
  filter(gwf_regime %in% c("Military", "Personal", "Party", "Monarchy"))  %>% 
  mutate(gwf_regime = factor(gwf_regime, levels = c("Personal", "Party", "Military", "Monarchy"))) %>% 
  mutate(gwf_regimetype = factor(gwf_regimetype, levels = c("personal", "military", "military-personal", "party-military", "party", 
                                                            "party-military-personal", "party-personal", "monarchy"))) 
d2 <- d1 %>% 
  filter(gwf_regime != "Monarchy")
#with monarchies
w1 <- survreg(Surv(gwf_duration, gwf_fail)~ auto_pi + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w1coef <- exp(-w1$coefficients/w1$scale)
p1 <- summary(w1)$table[2,4]
w2 <- survreg(Surv(gwf_duration, gwf_fail)~ auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w2coef <- exp(-w2$coefficients/w2$scale)
p2 <- summary(w2)$table[2,4]
w3 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime  + auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w3coef <- exp(-w3$coefficients/w3$scale)
p3 <- summary(w3)$table[5,4]
w4 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regimetype  + auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w4coef <- exp(-w4$coefficients/w4$scale)
p4 <- summary(w4)$table[9,4]
#without
w5 <- survreg(Surv(gwf_duration, gwf_fail)~ auto_pi + factor(countryname) + factor(year), data= d2, na.action=na.omit, dist="weibull")
w5coef <- exp(-w5$coefficients/w5$scale)
p5 <- summary(w5)$table[5,4]
w6 <- survreg(Surv(gwf_duration, gwf_fail)~ auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC + factor(countryname) + factor(year), data = d2, na.action=na.omit, dist="weibull")
w6coef <- exp(-w6$coefficients/w6$scale)
p6 <- summary(w6)$table[2,4]
w7 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime  + auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC + factor(countryname) + factor(year), data = d2, na.action=na.omit, dist="weibull")
w7coef <- exp(-w7$coefficients/w7$scale)
p7 <- summary(w7)$table[5,4]
w8 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regimetype  + auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC + factor(countryname), data = d2, na.action=na.omit, dist="weibull")
w8coef <- exp(-w8$coefficients/w8$scale)
p8 <- summary(w8)$table[9,4]

w1stderror <- weibullstderror(w1)
w2stderror <- weibullstderror(w2)
w3stderror <- weibullstderror(w3)
w4stderror <- weibullstderror(w4)
w5stderror <- weibullstderror(w5)
w6stderror <- weibullstderror(w6)
w7stderror <- weibullstderror(w7)
w8stderror <- weibullstderror(w8)

ps <- list(p1, p2, p3, p4, p5, p6, p7, p8)

stargazer(w1, w2, w3, w4, w5, w6, w7, w8, coef = list(w1coef, w2coef, w3coef, w4coef, w5coef, w6coef, w7coef, w8coef), 
          se = list(w1stderror, w2stderror, w3stderror, w4stderror, w5stderror, w6stderror, w7stderror, w8stderror), 
          digits = 2, dep.var.labels = "Regime Survival",
          omit = c("oppo_auto", "lgmilex_cap", "lgpec", "lgupop", "e_migdppcln", "e_Total_Resources_Income_PC", 
                   "gwf_regimeParty", "gwf_regimeMilitary", "gwf_regimeMonarchy", "gwf_regimetypemilitary",
                   "gwf_regimetypemilitary-personal", "gwf_regimetypeparty-military", "gwf_regimetypeparty", 
                   "gwf_regimetypeparty-military-personal", "gwf_regimetypeparty-personal", "gwf_regimetypemonarchy",
                   "Constant", "countryname", "year"), 
          keep.stat = c("n", "rsq", "max.rsq"), omit.stat = c("chi2", "ll"), covariate.labels = "APS",
          column.labels = c("With Monarchies", "Without Monarchies"),
          column.separate = c(4, 4), add.lines = list(c("Non-regime Controls", "No", "Yes", "Yes", "Yes", "No", "Yes", "Yes", "Yes"),
                                                      c("Regime Controls", "No", "No", "Yes", "No", "No", "No", "Yes", "No"),
                                                      c("Hybrid Controls", "No", "No", "No", "Yes", "No", "No", "No", "Yes"),
                                                      c("Fixed Effects", "Yes", "Yes", "Yes", "Yes", "Yes", "Yes", "Yes", "Yes")), 
          p.auto = FALSE, p = ps)



##Table 2 replication with Weibull#####
d1 <- read_csv("data/panel.csv") %>% 
  select(countryname, cowcode, year, v2xps_party, starts_with("v2ps"), gwf_regime, gwf_duration, gwf_fail, auto_pi, oppo_auto, cpi, milex, milper, lgmilex_cap, irst, lgpec, tpop, lgupop, cinc, e_migdppcln,  e_Total_Resources_Income_PC) %>% 
  mutate(v2pssunpar = -1*v2pssunpar, v2pscnslnl = -1*v2pscnslnl, v2psprlnks = -1*v2psprlnks) %>% 
  mutate_at(vars(starts_with("v2ps")), funs(ifelse(v2xps_party == 0, 0, .))) %>% 
  filter(gwf_duration < 100) %>% 
  mutate(cowcode = as.character(cowcode)) %>% 
  filter(gwf_regime %in% c("Military", "Personal", "Party")) 

w1 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime + v2psorgs + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w1coef <- exp(-w1$coefficients/w1$scale)

w2 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime + v2psprbrch + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w2coef <- exp(-w2$coefficients/w2$scale)

w3 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime + v2pscnslnl + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w3coef <- exp(-w3$coefficients/w3$scale)

w4 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime + v2psprlnks + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w4coef <- exp(-w4$coefficients/w4$scale)

w5 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime + v2pssunpar + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w5coef <- exp(-w5$coefficients/w5$scale)

w6 <- survreg(Surv(gwf_duration, gwf_fail)~ v2psorgs + v2psprbrch + v2pscnslnl + v2psprlnks + v2pssunpar + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w6coef <- exp(-w6$coefficients/w6$scale)

w7 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime + v2psorgs + v2psprbrch + v2pscnslnl + v2psprlnks + v2pssunpar + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w7coef <- exp(-w7$coefficients/w7$scale)

w8 <- survreg(Surv(gwf_duration, gwf_fail)~ v2psorgs + v2psprbrch + v2pscnslnl + v2psprlnks + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w8coef <- exp(-w8$coefficients/w8$scale)

w9 <- survreg(Surv(gwf_duration, gwf_fail)~ gwf_regime + v2psorgs + v2psprbrch + v2pscnslnl + v2psprlnks + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC + factor(countryname) + factor(year), data= d1, na.action=na.omit, dist="weibull")
w9coef <- exp(-w9$coefficients/w9$scale)

w1stderror <- weibullstderror(w1)
w2stderror <- weibullstderror(w2)
w3stderror <- weibullstderror(w3)
w4stderror <- weibullstderror(w4)
w5stderror <- weibullstderror(w5)
w6stderror <- weibullstderror(w6)
w7stderror <- weibullstderror(w7)
w8stderror <- weibullstderror(w8)
w9stderror <- weibullstderror(w9)

stargazer(w1, w2, w3, w4, w5, w6, w7, w8, w9,
          coef = list(w1coef, w2coef, w3coef, w4coef, w5coef, w6coef, w7coef, w7coef, w8coef), 
          se = list(w1stderror, w2stderror, w3stderror, w4stderror, w5stderror, w6stderror, w7stderror, w8stderror, w9stderror),
          digits = 2, 
          order=c("v2psorgs", "v2psprbrch", "v2pscnslnl", "v2psprlnks", "v2pssunpar"),
          covariate.labels = c("Nat Org", "Branches", "Selection", "Linkages", "Sub-Nat"), 
          dep.var.labels = "Regime Survival",
          add.lines = list(c("Controls", "Yes", "Yes", "Yes", "Yes", "Yes", "No", "Yes", "No", "Yes"),
                           c("Fixed Effects", "Yes", "Yes", "Yes", "Yes", "Yes", "Yes", "Yes", "Yes", "Yes")), 
          omit = c("gwf_regime", "oppo_auto", "lgmilex_cap", "lgpec", "lgupop", "e_migdppcln", "e_Total_Resources_Income_PC",
                   "Constant", "countryname", "year"), omit.stat = c("chi2", "ll"),
          p.auto = TRUE)


####Figure 6 Weibull####
library(tidyverse)
library(survival)
library(broom)
library(stargazer)
library(prediction)

df <- read_csv("data/panel.csv") %>% 
  select(countryname, cowcode, year, v2xps_party, starts_with("v2ps"), gwf_regime, gwf_duration, gwf_fail, gwf_party, gwf_military, gwf_personal, gwf_monarchy, auto_pi, oppo_auto, cpi, milex, milper, lgmilex_cap, irst, lgpec, tpop, lgupop, cinc, e_migdppcln,  e_Total_Resources_Income_PC) %>% 
  filter(gwf_duration < 100) %>% 
  mutate(auto_pi = ifelse(v2xps_party == 0, 0, auto_pi)) %>% 
  mutate(cowcode = as.character(cowcode)) %>% 
  filter(gwf_regime %in% c("Military", "Personal", "Party", "Monarchy")) %>% 
  mutate(gwf_regime = fct_relevel(gwf_regime, "Monarchy", "Party", "Personal", "Military")) %>% 
  rename(party = gwf_party, mil = gwf_military, personal = gwf_personal, monarchy = gwf_monarchy) %>% 
  select(countryname, year, gwf_regime, party, personal, mil, monarchy, auto_pi, lgmilex_cap, lgpec, lgupop, e_migdppcln, e_Total_Resources_Income_PC, gwf_duration, gwf_fail) %>% 
  mutate(percentile = ntile(auto_pi, 100)) %>% 
  mutate(qtile = ifelse(percentile <= 25, "25th",
                        ifelse(percentile >= 75, "75th", "50th"))) %>% 
  na.omit()

m1 <- survreg(Surv(gwf_duration, gwf_fail) ~ gwf_regime*auto_pi + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC + factor(countryname) + factor(year), data= df, na.action=na.omit, dist="weibull")

p1 <- prediction(m1, type = "lp", at = list(gwf_regime = c("Party", "Military", "Personal"))) %>% 
  filter(gwf_regime != "Monarchy") %>% 
  select(gwf_regime, auto_pi, fitted, se.fitted)%>% 
  group_by(gwf_regime) %>% 
  mutate(lci = fitted - qnorm(0.975)*sd(fitted)/sqrt(n()), uci = fitted + qnorm(0.975)*sd(fitted)/sqrt(n())) %>% 
  group_by(gwf_regime, auto_pi) %>% 
  mutate(mean_fit = mean(fitted), mean_se = sqrt(sum(se.fitted^2))/sqrt(n()), mean_lci = mean(lci), mean_uci = mean(uci)) %>%   
  ungroup() %>% 
  select(gwf_regime, auto_pi, mean_fit, mean_se, mean_lci, mean_uci) %>% 
  distinct() %>% 
  filter(gwf_regime %in% c("Party", "Military", "Personal"), auto_pi <= .9 & auto_pi >=.3 & gwf_regime == "Personal" |
           auto_pi <= .9 & auto_pi >=.2 & gwf_regime == "Military" | auto_pi <= 1 & auto_pi >=.2 & gwf_regime == "Party")  

ggplot(p1, aes(x = auto_pi, y = mean_fit, color = gwf_regime)) +
  geom_smooth(method = "lm") +
  theme_bw() +
  theme(legend.position = "bottom", legend.title=element_blank()) +
  ylab("Relative Probability of Surviving") +
  xlab("Authoritarian Party Strength") +
  scale_color_grey(start = 0.0, end = 0.7) +
  xlim(.2,1)

ggsave(filename =  "figures/fig6_weibull.jpg")
