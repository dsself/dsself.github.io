weibullstderror <- function (model) 
{
  Int.Only <- (nrow(summary(model)$table) == 2)
  sigma <- summary(model)$scale
  k <- length(summary(model)$coef) - 1
  if (!Int.Only) {
    gamma <- summary(model)$coef[2:(k + 1)]
  }
  if (!Int.Only) {
    beta <- -gamma/sigma
  }
  var1 <- summary(model)$var
  var.sigma <- var1[(k + 2), (k + 2)] * exp(2 * log(sigma))
  if (!Int.Only) {
    var.gamma <- var1[2:(k + 1), 2:(k + 1)]
    if (k > 1) {
      var.gamma <- diag(var.gamma)
    }
    se.gamma <- sqrt(var.gamma)
  }
  if (!Int.Only) {
    cov.gamma.sigma <- var1[2:(k + 1), (k + 2)] * sigma
    var.beta <- (1/(sigma^2)) * (var.gamma - (2 * gamma/sigma) * 
                                   (cov.gamma.sigma) + (((gamma/sigma)^2) * var.sigma))
    se.beta <- sqrt(var.beta)
    std.err <- se.beta*exp(se.beta)

  }
 return(std.err)
}

save(weibullstderror, file = "data/weibullstderror.Rdta")
