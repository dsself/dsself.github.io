library(tidyverse)
library(survival)
library(broom)
library(stargazer)
library(margins)

d1 <- read_csv("data/panel.csv") %>% 
  select(countryname, cowcode, year, v2xps_party, starts_with("v2ps"), gwf_regime, gwf_regimetype, gwf_duration, gwf_fail, auto_pi, oppo_auto, cpi, milex, milper, lgmilex_cap, irst, lgpec, tpop, lgupop, cinc, e_migdppcln,  e_Total_Resources_Income_PC) %>% 
  filter(gwf_duration < 100) %>% 
  mutate(auto_pi = ifelse(v2xps_party == 0, 0, auto_pi)) %>% 
  mutate(cowcode = as.character(cowcode)) %>% 
  filter(gwf_regime %in% c("Military", "Personal", "Party", "Monarchy"))  %>% 
  mutate(gwf_regime = factor(gwf_regime, levels = c("Personal", "Party", "Military", "Monarchy"))) %>% 
  mutate(gwf_regimetype = factor(gwf_regimetype, levels = c("personal", "military", "military-personal", "party-military", "party", 
                                                            "party-military-personal", "party-personal", "monarchy"))) 

d2 <- d1 %>% 
  filter(gwf_regime != "Monarchy")
#with monarchies
cox1 <- coxph(Surv(gwf_duration, gwf_fail) ~ auto_pi, data = d1)
cox2 <- coxph(Surv(gwf_duration, gwf_fail) ~ auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
cox3 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime  + auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
cox4 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regimetype  + auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
#without
cox5 <- coxph(Surv(gwf_duration, gwf_fail) ~ auto_pi, data = d2)
cox6 <- coxph(Surv(gwf_duration, gwf_fail) ~ auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d2)
cox7 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime  + auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d2)
cox8 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regimetype  + auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d2)

stderr1 <- summary(cox1)$coefficients[,3]*exp(summary(cox1)$coefficients[,3])
stderr2 <- summary(cox2)$coefficients[,3]*exp(summary(cox2)$coefficients[,3])
stderr3 <- summary(cox3)$coefficients[,3]*exp(summary(cox3)$coefficients[,3])
stderr4 <- summary(cox4)$coefficients[,3]*exp(summary(cox4)$coefficients[,3])
stderr5 <- summary(cox5)$coefficients[,3]*exp(summary(cox5)$coefficients[,3])
stderr6 <- summary(cox6)$coefficients[,3]*exp(summary(cox6)$coefficients[,3])
stderr7 <- summary(cox7)$coefficients[,3]*exp(summary(cox7)$coefficients[,3])
stderr8 <- summary(cox8)$coefficients[,3]*exp(summary(cox8)$coefficients[,3])

p1 <- summary(cox1)$coefficients[,5]
p2 <- summary(cox2)$coefficients[,5]
p3 <- summary(cox3)$coefficients[,5]
p4 <- summary(cox4)$coefficients[,5]
p5 <- summary(cox5)$coefficients[,5]
p6 <- summary(cox6)$coefficients[,5]
p7 <- summary(cox7)$coefficients[,5]
p8 <- summary(cox8)$coefficients[,5]

pvalues <- list(p1, p2, p3, p4, p5, p6, p7, p8)

semult <- function(x) (x * exp(x))

stargazer(cox1, cox2, cox3, cox4, cox5, cox6, cox7, cox8,
          apply.coef = exp, apply.se = semult, digits = 2, dep.var.labels = "Regime Survival",
          omit = c("oppo_auto", "lgmilex_cap", "lgpec", "lgupop", "e_migdppcln", "e_Total_Resources_Income_PC", 
                   "gwf_regimeParty", "gwf_regimeMilitary", "gwf_regimeMonarchy", "gwf_regimetypemilitary",
                   "gwf_regimetypemilitary-personal", "gwf_regimetypeparty-military", "gwf_regimetypeparty", 
                   "gwf_regimetypeparty-military-personal", "gwf_regimetypeparty-personal", "gwf_regimetypemonarchy"), 
          keep.stat = c("n", "rsq", "max.rsq"), p.auto = FALSE, p = pvalues, covariate.labels = "APS",
          column.labels = c("With Monarchies", "Without Monarchies"),
          column.separate = c(4, 4), add.lines = list(c("Non-regime Controls", "No", "Yes", "Yes", "Yes", "No", "Yes", "Yes", "Yes"),
                                                      c("Regime Controls", "No", "No", "Yes", "No", "No", "No", "Yes", "No"),
                                                      c("Hybrid Controls", "No", "No", "No", "Yes", "No", "No", "No", "Yes")))

