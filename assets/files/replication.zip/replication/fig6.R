library(tidyverse)
library(survival)
library(broom)
library(stargazer)
library(prediction)

df <- read_csv("data/panel.csv") %>% 
  select(countryname, cowcode, year, v2xps_party, starts_with("v2ps"), gwf_regime, gwf_duration, gwf_fail, gwf_party, gwf_military, gwf_personal, gwf_monarchy, auto_pi, oppo_auto, cpi, milex, milper, lgmilex_cap, irst, lgpec, tpop, lgupop, cinc, e_migdppcln,  e_Total_Resources_Income_PC) %>% 
  filter(gwf_duration < 100) %>% 
  mutate(auto_pi = ifelse(v2xps_party == 0, 0, auto_pi)) %>% 
  mutate(cowcode = as.character(cowcode)) %>% 
  filter(gwf_regime %in% c("Military", "Personal", "Party", "Monarchy")) %>% 
  mutate(gwf_regime = fct_relevel(gwf_regime, "Monarchy", "Party", "Personal", "Military")) %>% 
  rename(party = gwf_party, mil = gwf_military, personal = gwf_personal, monarchy = gwf_monarchy) %>% 
  select(countryname, year, gwf_regime, party, personal, mil, monarchy, auto_pi, lgmilex_cap, lgpec, lgupop, e_migdppcln, e_Total_Resources_Income_PC, gwf_duration, gwf_fail) %>% 
  mutate(percentile = ntile(auto_pi, 100)) %>% 
  mutate(qtile = ifelse(percentile <= 25, "25th",
                        ifelse(percentile >= 75, "75th", "50th"))) %>% 
  na.omit()

m1 <- survreg(Surv(gwf_duration, gwf_fail) ~ gwf_regime*auto_pi + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = df)

p1 <- prediction(m1, type = "lp", at = list(gwf_regime = c("Party", "Military", "Personal"))) %>% 
  filter(gwf_regime != "Monarchy") %>% 
  select(gwf_regime, auto_pi, fitted, se.fitted)%>% 
  group_by(gwf_regime) %>% 
  mutate(lci = fitted - qnorm(0.975)*sd(fitted)/sqrt(n()), uci = fitted + qnorm(0.975)*sd(fitted)/sqrt(n())) %>% 
  group_by(gwf_regime, auto_pi) %>% 
  mutate(mean_fit = mean(fitted), mean_se = sqrt(sum(se.fitted^2))/sqrt(n()), mean_lci = mean(lci), mean_uci = mean(uci)) %>%   
  ungroup() %>% 
  select(gwf_regime, auto_pi, mean_fit, mean_se, mean_lci, mean_uci) %>% 
  distinct() %>% 
  filter(gwf_regime %in% c("Party", "Military", "Personal"), auto_pi <= .9 & auto_pi >=.3 & gwf_regime == "Personal" |
           auto_pi <= .9 & auto_pi >=.2 & gwf_regime == "Military" | auto_pi <= 1 & auto_pi >=.2 & gwf_regime == "Party")  

ggplot(p1, aes(x = auto_pi, y = mean_fit, color = gwf_regime)) +
  geom_smooth(method = "lm") +
  theme_bw() +
  theme(legend.position = "bottom", legend.title=element_blank()) +
  ylab("Relative Probability of Surviving") +
  xlab("Authoritarian Party Strength") +
  scale_color_grey(start = 0.0, end = 0.7) +
  xlim(.2,1)

ggsave(filename =  "figures/fig6.jpg")
