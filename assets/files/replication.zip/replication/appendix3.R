#appendix tables for figure 6
#just do auto_pi, then add controls

library(tidyverse)
library(survival)
library(broom)
library(stargazer)

df <- read_csv("data/panel.csv") %>% 
  select(countryname, cowcode, year, v2xps_party, starts_with("v2ps"), gwf_regime, gwf_duration, gwf_fail, gwf_party, gwf_military, gwf_personal, gwf_monarchy, auto_pi, oppo_auto, cpi, milex, milper, lgmilex_cap, irst, lgpec, tpop, lgupop, cinc, e_migdppcln,  e_Total_Resources_Income_PC) %>% 
  filter(gwf_duration < 100) %>% 
  mutate(auto_pi = ifelse(v2xps_party == 0, 0, auto_pi)) %>% 
  mutate(cowcode = as.character(cowcode)) %>% 
  filter(gwf_regime %in% c("Military", "Personal", "Party", "Monarchy")) %>% 
  mutate(gwf_regime = fct_relevel(gwf_regime, "Monarchy", "Party", "Personal", "Military")) %>% 
  rename(party = gwf_party, mil = gwf_military, personal = gwf_personal, monarchy = gwf_monarchy) %>% 
  select(countryname, year, gwf_regime, party, personal, mil, monarchy, auto_pi, lgmilex_cap, lgpec, lgupop, e_migdppcln, e_Total_Resources_Income_PC, gwf_duration, gwf_fail) %>% 
  mutate(percentile = ntile(auto_pi, 100)) %>% 
  mutate(qtile = ifelse(percentile <= 25, "25th",
                        ifelse(percentile >= 75, "75th", "50th"))) %>% 
  na.omit()

cox1 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime*auto_pi, data = df)
cox2 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime*auto_pi + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = df)

stderr1 <- summary(cox1)$coefficients[,3]*exp(summary(cox1)$coefficients[,3])
stderr2 <- summary(cox2)$coefficients[,3]*exp(summary(cox2)$coefficients[,3])

p1 <- summary(cox1)$coefficients[,5]
p2 <- summary(cox2)$coefficients[,5]

pvalues <- list(p1, p2)

semult <- function(x) (x * exp(x))

stargazer(cox1, cox2, 
          apply.coef = exp, apply.se = semult, digits = 2, dep.var.labels = "Regime Survival",
          omit = c("oppo_auto", "lgmilex_cap", "lgpec", "lgupop", "e_migdppcln", "e_Total_Resources_Income_PC"), 
          keep.stat = c("n", "rsq", "max.rsq"), p.auto = FALSE, p = pvalues, 
          covariate.labels = c("Party", "Personal", "Military", "APS", "Party*APS", "Personal*APS", "Military*APS"),
          add.lines = list(c("Non-regime Controls", "No", "Yes", "No", "Yes")))

