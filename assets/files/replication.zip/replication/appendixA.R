library(ggcorrplot)
library(tidyverse)
library(reshape2)
library(standard)

scale2 <- function(x, na.rm = T) ((x - min(x, na.rm = T))/(max(x, na.rm = T)-min(x, na.rm = T)))

read_csv("data/panel.csv") %>% 
  filter(gwf_regime %in% c("Military", "Party", "Personal", "Monarchy")) %>% 
  select(v2psorgs, v2psprbrch, v2psprlnks, v2pscnslnl, v2pssunpar, auto_pi) %>% 
  na.omit() %>% 
  mutate(Nat_Org = scale(v2psorgs), Branches = scale(v2psprbrch), Selection = scale(-1*v2pscnslnl), Linkages = scale(-1*v2psprlnks), Sub_Nat = scale(-1 * v2pssunpar)) %>% 
  select(auto_pi, Nat_Org, Branches, Selection, Linkages, Sub_Nat) %>% 
  mutate_all(scale2) %>% 
  melt(., id = "auto_pi") %>% 
  ggplot(.) +
  geom_boxplot(aes(x=variable,y=value)) +
  theme_bw() +
  xlab("Components of APS") +
  ylab("Value") +
  scale_x_discrete(labels = c("Nat Org", "Branches", "Selection", "Linkages", "Sub Nat")) +
  ggsave(file = "figures/a1.jpg", dpi = 500, width = 5, height = 5)

read_csv("data/panel.csv") %>% 
  filter(gwf_regime %in% c("Military", "Party", "Personal", "Monarchy")) %>% 
  select(auto_pi, auto_pim, auto_pifa, v2xps_party ) %>% 
  melt(., id = "v2xps_party") %>% 
  ggplot(.) +
  geom_boxplot(aes(x=variable,y=value)) +
  theme_bw() +
  xlab("Components of APS") +
  ylab("Value") +
  scale_x_discrete(labels = c("Additive", "Multiplicative", "Factor Analysis")) +
  ggsave(file = "figures/a2.jpg", dpi = 500, width = 5, height = 5)

d1 <- read_csv("data/GWFpersonalism.csv") %>% 
  mutate(countryname = country_panel(gwf_country, year)) %>% 
  select(countryname, year, GWF_Personalism = latent_personalism) 

read_csv("data/panel.csv") %>% 
  filter(gwf_regime %in% c("Military", "Party", "Personal", "Monarchy")) %>% 
  select(countryname, year, v2psorgs, v2psprbrch, v2psprlnks, v2pscnslnl, v2pssunpar) %>% 
  na.omit() %>% 
  mutate(Nat_Org = scale(v2psorgs), Branches = scale(v2psprbrch), Selection = scale(-1*v2pscnslnl), Linkages = scale(-1*v2psprlnks), Sub_Nat = scale(-1 * v2pssunpar)) %>% 
  select(countryname, year, Nat_Org, Branches, Selection, Linkages, Sub_Nat) %>% 
  left_join(d1, by = c("countryname", "year")) %>% 
  select(-countryname, -year) %>% 
  cor(., use = "pairwise.complete.obs") %>% 
  ggcorrplot(., method = "square", type = "upper", lab = "true", colors = c("dimgrey", "lightgrey", "white")) +
  scale_x_discrete(position = "top") +
  theme(axis.text.x = element_text(hjust = 0.25)) +
  theme(legend.justification = c(0,0), legend.position = c(0.75,0)) +
  ggsave(file = "figures/a3.jpg", dpi = 500, width = 5, height = 5)
  
library(foreign)
library(gplots)

d1 <- read_csv("data/panel.csv")

jpeg(file = "figures/a4.jpeg")
plotmeans(auto_pi ~ countryname, main = "Heterogeineity Across countryname", data = d1, xlab = "Country", ylab = "Authoritarian Party Strength")
dev.off()

jpeg(file = "figures/a5.jpeg")
plotmeans(auto_pi ~ year, main = "Heterogeineity Across Year", data = d1, xlab = "Yea", ylab = "Authoritarian Party Strength")
dev.off()