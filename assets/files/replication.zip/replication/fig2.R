library(tidyverse)

d1 <- read_csv("data/panel.csv") %>% 
  select(countryname, year, gwf_regime, auto_pi) %>% 
  mutate(gwf_regime = factor(gwf_regime, levels = c("Party", "Military", "Personal", "Monarchy"))) 

ggplot(d1) +
  geom_boxplot(aes(x = gwf_regime, y = auto_pi)) +
  theme_bw() +
  ylab("Autocratic Party Strength") +
  xlab("Regime Type")

ggsave("figures/fig2.jpg", dpi = 500)

ggplot(d1, aes(x=factor(gwf_regime), y=auto_pi, fill=factor(gwf_regime))) + 
  geom_boxplot(width=0.6) +
  stat_summary(geom="text", fun.y=quantile,
               aes(label=sprintf("%1.1f", ..y..), color=factor(gwf_regime)),
               position=position_nudge(x=0.33), size=3.5) +
  theme_bw()
