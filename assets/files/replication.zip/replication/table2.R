library(tidyverse)
library(survival)
library(broom)
library(stargazer)

d1 <- read_csv("data/panel.csv") %>% 
  select(countryname, cowcode, year, v2xps_party, starts_with("v2ps"), gwf_regime, gwf_duration, gwf_fail, auto_pi, oppo_auto, cpi, milex, milper, lgmilex_cap, irst, lgpec, tpop, lgupop, cinc, e_migdppcln,  e_Total_Resources_Income_PC) %>% 
  mutate(v2pssunpar = -1*v2pssunpar, v2pscnslnl = -1*v2pscnslnl, v2psprlnks = -1*v2psprlnks) %>% 
  mutate_at(vars(starts_with("v2ps")), funs(ifelse(v2xps_party == 0, 0, .))) %>% 
  filter(gwf_duration < 100) %>% 
  mutate(cowcode = as.character(cowcode)) %>% 
  filter(gwf_regime %in% c("Military", "Personal", "Party")) 

cox1.1 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime + v2psorgs + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
cox1.2 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime + v2psprbrch + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
cox1.3 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime + v2pscnslnl + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
cox1.4 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime + v2psprlnks + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
cox1.5 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime + v2pssunpar + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
cox1.6 <- coxph(Surv(gwf_duration, gwf_fail) ~ v2psorgs + v2psprbrch + v2pscnslnl + v2psprlnks + v2pssunpar, data = d1)
cox1.7 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime + v2psorgs + v2psprbrch + v2pscnslnl + v2psprlnks + v2pssunpar + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
cox1.8 <- coxph(Surv(gwf_duration, gwf_fail) ~ v2psorgs + v2psprbrch + v2pscnslnl + v2psprlnks, data = d1)
cox1.9 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime + v2psorgs + v2psprbrch + v2pscnslnl + v2psprlnks + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)

stderr1.1 <- summary(cox1.1)$coefficients[,3]*exp(summary(cox1.1)$coefficients[,3])
stderr1.2 <- summary(cox1.2)$coefficients[,3]*exp(summary(cox1.2)$coefficients[,3])
stderr1.3 <- summary(cox1.3)$coefficients[,3]*exp(summary(cox1.3)$coefficients[,3])
stderr1.4 <- summary(cox1.4)$coefficients[,3]*exp(summary(cox1.4)$coefficients[,3])
stderr1.5 <- summary(cox1.5)$coefficients[,3]*exp(summary(cox1.5)$coefficients[,3])
stderr1.6 <- summary(cox1.6)$coefficients[,3]*exp(summary(cox1.6)$coefficients[,3])
stderr1.7 <- summary(cox1.7)$coefficients[,3]*exp(summary(cox1.7)$coefficients[,3])
stderr1.8 <- summary(cox1.8)$coefficients[,3]*exp(summary(cox1.8)$coefficients[,3])
stderr1.9 <- summary(cox1.9)$coefficients[,3]*exp(summary(cox1.9)$coefficients[,3])


p1.1 <- summary(cox1.1)$coefficients[,5]
p1.2 <- summary(cox1.2)$coefficients[,5]
p1.3 <- summary(cox1.3)$coefficients[,5]
p1.4 <- summary(cox1.4)$coefficients[,5]
p1.5 <- summary(cox1.5)$coefficients[,5]
p1.6 <- summary(cox1.6)$coefficients[,5]
p1.7 <- summary(cox1.7)$coefficients[,5]
p1.8 <- summary(cox1.8)$coefficients[,5]
p1.9 <- summary(cox1.9)$coefficients[,5]

pvalues <- list(p1.1, p1.2, p1.3, p1.4, p1.5, p1.6, p1.7, p1.8, p1.9)

semult <- function(x) (x * exp(x))

stargazer(cox1.1, cox1.2, cox1.3, cox1.4, cox1.5, cox1.6, cox1.7, cox1.8, cox1.9,
          apply.coef = exp, apply.se = semult, digits = 2, omit.stat = c("chi2", "ll", "wald", "lr", "logrank"),
          covariate.labels = c("Nat Org", "Branches", "Selection", "Linkages", "Sub-Nat"),  dep.var.labels = "Regime Survival",
          add.lines = list(c("Controls", "Yes", "Yes", "Yes", "Yes", "Yes", "No", "Yes", "No", "Yes")), omit = c("gwf_regime", "oppo_auto", "lgmilex_cap", "lgpec", "lgupop", "e_migdppcln", 
                                                                                                           "e_Total_Resources_Income_PC"), 
           p.auto = FALSE, p = pvalues)
