library(tidyverse)
library(survival)
library(broom)
library(stargazer)
library(margins)


####Table 1 replacing 0s to NA####
d1 <- read_csv("data/panel.csv") %>% 
  select(countryname, cowcode, year, v2xps_party, starts_with("v2ps"), gwf_regime, gwf_regimetype, gwf_duration, gwf_fail, auto_pi, oppo_auto, cpi, milex, milper, lgmilex_cap, irst, lgpec, tpop, lgupop, cinc, e_migdppcln,  e_Total_Resources_Income_PC) %>% 
  filter(gwf_duration < 100) %>% 
  mutate(auto_pi = ifelse(v2xps_party == 0, NA, auto_pi)) %>% 
  mutate(cowcode = as.character(cowcode)) %>% 
  filter(gwf_regime %in% c("Military", "Personal", "Party", "Monarchy"))  %>% 
  mutate(gwf_regime = factor(gwf_regime, levels = c("Personal", "Party", "Military", "Monarchy"))) %>% 
  mutate(gwf_regimetype = factor(gwf_regimetype, levels = c("personal", "military", "military-personal", "party-military", "party", 
                                                            "party-military-personal", "party-personal", "monarchy"))) 

d2 <- d1 %>% 
  filter(gwf_regime != "Monarchy")
#with monarchies
cox1 <- coxph(Surv(gwf_duration, gwf_fail) ~ auto_pi, data = d1)
cox2 <- coxph(Surv(gwf_duration, gwf_fail) ~ auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
cox3 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime  + auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
cox4 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regimetype  + auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
#without
cox5 <- coxph(Surv(gwf_duration, gwf_fail) ~ auto_pi, data = d2)
cox6 <- coxph(Surv(gwf_duration, gwf_fail) ~ auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d2)
cox7 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime  + auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d2)
cox8 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regimetype  + auto_pi + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d2)

stderr1 <- summary(cox1)$coefficients[,3]*exp(summary(cox1)$coefficients[,3])
stderr2 <- summary(cox2)$coefficients[,3]*exp(summary(cox2)$coefficients[,3])
stderr3 <- summary(cox3)$coefficients[,3]*exp(summary(cox3)$coefficients[,3])
stderr4 <- summary(cox4)$coefficients[,3]*exp(summary(cox4)$coefficients[,3])
stderr5 <- summary(cox5)$coefficients[,3]*exp(summary(cox5)$coefficients[,3])
stderr6 <- summary(cox6)$coefficients[,3]*exp(summary(cox6)$coefficients[,3])
stderr7 <- summary(cox7)$coefficients[,3]*exp(summary(cox7)$coefficients[,3])
stderr8 <- summary(cox8)$coefficients[,3]*exp(summary(cox8)$coefficients[,3])

p1 <- summary(cox1)$coefficients[,5]
p2 <- summary(cox2)$coefficients[,5]
p3 <- summary(cox3)$coefficients[,5]
p4 <- summary(cox4)$coefficients[,5]
p5 <- summary(cox5)$coefficients[,5]
p6 <- summary(cox6)$coefficients[,5]
p7 <- summary(cox7)$coefficients[,5]
p8 <- summary(cox8)$coefficients[,5]

pvalues <- list(p1, p2, p3, p4, p5, p6, p7, p8)

semult <- function(x) (x * exp(x))

stargazer(cox1, cox2, cox3, cox4, cox5, cox6, cox7, cox8,
          apply.coef = exp, apply.se = semult, digits = 2, dep.var.labels = "Regime Survival",
          omit = c("oppo_auto", "lgmilex_cap", "lgpec", "lgupop", "e_migdppcln", "e_Total_Resources_Income_PC", 
                   "gwf_regimeParty", "gwf_regimeMilitary", "gwf_regimeMonarchy", "gwf_regimetypemilitary",
                   "gwf_regimetypemilitary-personal", "gwf_regimetypeparty-military", "gwf_regimetypeparty", 
                   "gwf_regimetypeparty-military-personal", "gwf_regimetypeparty-personal", "gwf_regimetypemonarchy"), 
          keep.stat = c("n", "rsq", "max.rsq"), p.auto = FALSE, p = pvalues, covariate.labels = "APS",
          column.labels = c("With Monarchies", "Without Monarchies"),
          column.separate = c(4, 4), add.lines = list(c("Non-regime Controls", "No", "Yes", "Yes", "Yes", "No", "Yes", "Yes", "Yes"),
                                                      c("Regime Controls", "No", "No", "Yes", "No", "No", "No", "Yes", "No"),
                                                      c("Hybrid Controls", "No", "No", "No", "Yes", "No", "No", "No", "Yes")))

####Table 2####
d1 <- read_csv("data/panel.csv") %>% 
  select(countryname, cowcode, year, v2xps_party, starts_with("v2ps"), gwf_regime, gwf_duration, gwf_fail, auto_pi, oppo_auto, cpi, milex, milper, lgmilex_cap, irst, lgpec, tpop, lgupop, cinc, e_migdppcln,  e_Total_Resources_Income_PC) %>% 
  mutate(v2pssunpar = -1*v2pssunpar, v2pscnslnl = -1*v2pscnslnl, v2psprlnks = -1*v2psprlnks) %>% 
  mutate_at(vars(starts_with("v2ps")), funs(ifelse(v2xps_party == 0, NA, .))) %>% 
  filter(gwf_duration < 100) %>% 
  mutate(cowcode = as.character(cowcode)) %>% 
  filter(gwf_regime %in% c("Military", "Personal", "Party")) 

cox1.1 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime + v2psorgs + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
cox1.2 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime + v2psprbrch + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
cox1.3 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime + v2pscnslnl + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
cox1.4 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime + v2psprlnks + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
cox1.5 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime + v2pssunpar + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
cox1.6 <- coxph(Surv(gwf_duration, gwf_fail) ~ v2psorgs + v2psprbrch + v2pscnslnl + v2psprlnks + v2pssunpar, data = d1)
cox1.7 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime + v2psorgs + v2psprbrch + v2pscnslnl + v2psprlnks + v2pssunpar + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)
cox1.8 <- coxph(Surv(gwf_duration, gwf_fail) ~ v2psorgs + v2psprbrch + v2pscnslnl + v2psprlnks, data = d1)
cox1.9 <- coxph(Surv(gwf_duration, gwf_fail) ~ gwf_regime + v2psorgs + v2psprbrch + v2pscnslnl + v2psprlnks + oppo_auto + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = d1)

stderr1.1 <- summary(cox1.1)$coefficients[,3]*exp(summary(cox1.1)$coefficients[,3])
stderr1.2 <- summary(cox1.2)$coefficients[,3]*exp(summary(cox1.2)$coefficients[,3])
stderr1.3 <- summary(cox1.3)$coefficients[,3]*exp(summary(cox1.3)$coefficients[,3])
stderr1.4 <- summary(cox1.4)$coefficients[,3]*exp(summary(cox1.4)$coefficients[,3])
stderr1.5 <- summary(cox1.5)$coefficients[,3]*exp(summary(cox1.5)$coefficients[,3])
stderr1.6 <- summary(cox1.6)$coefficients[,3]*exp(summary(cox1.6)$coefficients[,3])
stderr1.7 <- summary(cox1.7)$coefficients[,3]*exp(summary(cox1.7)$coefficients[,3])
stderr1.8 <- summary(cox1.8)$coefficients[,3]*exp(summary(cox1.8)$coefficients[,3])
stderr1.9 <- summary(cox1.9)$coefficients[,3]*exp(summary(cox1.9)$coefficients[,3])


p1.1 <- summary(cox1.1)$coefficients[,5]
p1.2 <- summary(cox1.2)$coefficients[,5]
p1.3 <- summary(cox1.3)$coefficients[,5]
p1.4 <- summary(cox1.4)$coefficients[,5]
p1.5 <- summary(cox1.5)$coefficients[,5]
p1.6 <- summary(cox1.6)$coefficients[,5]
p1.7 <- summary(cox1.7)$coefficients[,5]
p1.8 <- summary(cox1.8)$coefficients[,5]
p1.9 <- summary(cox1.9)$coefficients[,5]

pvalues <- list(p1.1, p1.2, p1.3, p1.4, p1.5, p1.6, p1.7, p1.8, p1.9)

semult <- function(x) (x * exp(x))

stargazer(cox1.1, cox1.2, cox1.3, cox1.4, cox1.5, cox1.6, cox1.7, cox1.8, cox1.9,
          apply.coef = exp, apply.se = semult, digits = 2, omit.stat = c("chi2", "ll", "wald", "lr", "logrank"),
          covariate.labels = c("Nat Org", "Branches", "Selection", "Linkages", "Sub-Nat"),  dep.var.labels = "Regime Survival",
          add.lines = list(c("Controls", "Yes", "Yes", "Yes", "Yes", "Yes", "No", "Yes", "No", "Yes")), omit = c("gwf_regime", "oppo_auto", "lgmilex_cap", "lgpec", "lgupop", "e_migdppcln", 
                                                                                                                 "e_Total_Resources_Income_PC"), 
          p.auto = FALSE, p = pvalues)

####Fig 5####
d1 <- read_csv("data/panel.csv") %>% 
  filter(gwf_duration < 100) %>% 
  mutate(auto_pi = ifelse(v2xps_party == 0, NA, auto_pi)) %>% 
  mutate(ntile = ntile(auto_pi, 3)) %>% 
  mutate(ntile = ifelse(ntile == 1, "Low", ifelse(ntile == 2, "Mid", ifelse(ntile == 3, "High", NA)))) 

km1 <- tidy(survfit(Surv(gwf_duration, gwf_fail) ~ ntile, data = d1)) %>% 
  na.omit() %>% 
  mutate(Tercile = ifelse(strata == "ntile=Low", "Low", 
                          ifelse(strata == "ntile=Mid", "Mid", 
                                 ifelse(strata == "ntile=High", "High", NA)))) 

ggplot(km1) +
  geom_line(aes(x = time, y = estimate, color = Tercile, linetype = Tercile)) +
  geom_ribbon(aes(x = time, y = estimate, ymin = conf.low, ymax = conf.high, fill = Tercile), alpha = 0.2) +
  theme_bw() +
  scale_color_grey() +
  scale_fill_grey() +
  theme(legend.position="bottom") +
  ylab("Estimate") +
  xlab("Duration") +
  ylim(0.5, 1) +
  scale_linetype_manual(values=c("dotted", "solid", "dotdash"))

ggsave("figures/fig5_na.jpg", dpi = 500)
####Fig 6####
df <- read_csv("data/panel.csv") %>% 
  select(countryname, cowcode, year, v2xps_party, starts_with("v2ps"), gwf_regime, gwf_duration, gwf_fail, gwf_party, gwf_military, gwf_personal, gwf_monarchy, auto_pi, oppo_auto, cpi, milex, milper, lgmilex_cap, irst, lgpec, tpop, lgupop, cinc, e_migdppcln,  e_Total_Resources_Income_PC) %>% 
  filter(gwf_duration < 100) %>% 
  mutate(auto_pi = ifelse(v2xps_party == 0, NA, auto_pi)) %>% 
  mutate(cowcode = as.character(cowcode)) %>% 
  filter(gwf_regime %in% c("Military", "Personal", "Party", "Monarchy")) %>% 
  mutate(gwf_regime = fct_relevel(gwf_regime, "Monarchy", "Party", "Personal", "Military")) %>% 
  rename(party = gwf_party, mil = gwf_military, personal = gwf_personal, monarchy = gwf_monarchy) %>% 
  select(countryname, year, gwf_regime, party, personal, mil, monarchy, auto_pi, lgmilex_cap, lgpec, lgupop, e_migdppcln, e_Total_Resources_Income_PC, gwf_duration, gwf_fail) %>% 
  mutate(percentile = ntile(auto_pi, 100)) %>% 
  mutate(qtile = ifelse(percentile <= 25, "25th",
                        ifelse(percentile >= 75, "75th", "50th"))) %>% 
  na.omit()

m1 <- survreg(Surv(gwf_duration, gwf_fail) ~ gwf_regime*auto_pi + lgmilex_cap + lgpec + lgupop + e_migdppcln + e_Total_Resources_Income_PC, data = df)

p1 <- prediction(m1, type = "lp", at = list(gwf_regime = c("Party", "Military", "Personal"))) %>% 
  filter(gwf_regime != "Monarchy") %>% 
  select(gwf_regime, auto_pi, fitted, se.fitted)%>% 
  group_by(gwf_regime) %>% 
  mutate(lci = fitted - qnorm(0.975)*sd(fitted)/sqrt(n()), uci = fitted + qnorm(0.975)*sd(fitted)/sqrt(n())) %>% 
  group_by(gwf_regime, auto_pi) %>% 
  mutate(mean_fit = mean(fitted), mean_se = sqrt(sum(se.fitted^2))/sqrt(n()), mean_lci = mean(lci), mean_uci = mean(uci)) %>%   
  ungroup() %>% 
  select(gwf_regime, auto_pi, mean_fit, mean_se, mean_lci, mean_uci) %>% 
  distinct() %>% 
  filter(gwf_regime %in% c("Party", "Military", "Personal"), auto_pi <= .9 & auto_pi >=.3 & gwf_regime == "Personal" |
           auto_pi <= .9 & auto_pi >=.2 & gwf_regime == "Military" | auto_pi <= 1 & auto_pi >=.2 & gwf_regime == "Party")  

ggplot(p1, aes(x = auto_pi, y = mean_fit, color = gwf_regime)) +
  geom_smooth(method = "lm") +
  theme_bw() +
  theme(legend.position = "bottom", legend.title=element_blank()) +
  ylab("Relative Probability of Surviving") +
  xlab("Authoritarian Party Strength") +
  scale_color_grey(start = 0.0, end = 0.7)

ggsave(filename =  "figures/fig6_na.jpg")
