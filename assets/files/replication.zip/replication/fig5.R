library(tidyverse)
library(survival)
library(broom)


d1 <- read_csv("data/panel.csv") %>% 
  filter(gwf_duration < 100) %>% 
  mutate(auto_pi = ifelse(v2xps_party == 0, NA, auto_pi)) %>% 
  mutate(ntile = ntile(auto_pi, 3)) %>% 
  mutate(ntile = ifelse(ntile == 1, "Low", ifelse(ntile == 2, "Mid", ifelse(ntile == 3, "High", NA)))) 

km1 <- tidy(survfit(Surv(gwf_duration, gwf_fail) ~ ntile, data = d1)) %>% 
  na.omit() %>% 
  mutate(Tercile = ifelse(strata == "ntile=Low", "Low", 
                          ifelse(strata == "ntile=Mid", "Mid", 
                                 ifelse(strata == "ntile=High", "High", NA)))) 

ggplot(km1) +
  geom_line(aes(x = time, y = estimate, color = Tercile, linetype = Tercile)) +
  geom_ribbon(aes(x = time, y = estimate, ymin = conf.low, ymax = conf.high, fill = Tercile), alpha = 0.2) +
  theme_bw() +
  scale_color_grey() +
  scale_fill_grey() +
  theme(legend.position="bottom") +
  ylab("Estimate") +
  xlab("Duration") +
  ylim(0.5, 1) +
  scale_linetype_manual(values=c("dotted", "solid", "dotdash"))

ggsave("figures/fig5.jpg", dpi = 500)
