library(tidyverse)
d1 <- read_csv("data/nmc.csv") %>% 
  mutate(milex = ifelse(milex == -9, NA, milex))

d2 <- read_csv("data/cpi.csv") %>% 
  mutate(year = as.integer(year))

#using fed reserve of minnisota cpi data
d3 <- left_join(d1, d2, by = "year") %>% 
  na.omit() %>% 
  mutate(milex_2000 = (cpi/172.2)*milex) %>% 
  mutate(ccode = ifelse(ccode == 816, 818, ccode)) %>% 
  rename(cowcode = ccode)

d4 <- read_csv("data/Master Panel_v8.csv") %>% 
  select(countryname, cowcode, year, e_regionpol, starts_with("v2"), starts_with("gwf"), e_migdppcln, e_Fiscal_Reliance, e_Total_Resources_Income_PC) %>% 
                                  #permanent national org #local branches      #candidate selection (nat) #clientelism     #subnat party control 
  mutate(auto_pi = as.numeric((scale(v2psorgs) + scale(v2psprbrch) + scale(-1*v2pscnslnl) + scale(-1*v2psprlnks) + scale(-1 * v2pssunpar))/5), 
         auto_pi = ((auto_pi - min(auto_pi, na.rm = T))/(max(auto_pi, na.rm = T)-min(auto_pi, na.rm = T)))) %>% 
  mutate(oppo_auto = as.numeric((scale(v2psparban) + scale(v2psbars) + scale(v2psoppaut))/3), 
         oppo_auto = ((oppo_auto - min(oppo_auto, na.rm = T))/(max(oppo_auto, na.rm = T)-min(oppo_auto, na.rm = T)))) %>% 
  mutate(ntile = ntile(auto_pi, 3)) %>% 
  mutate(ntile = ifelse(ntile == 1, "Low", ifelse(ntile == 2, "Mid", ifelse(ntile == 3, "High", NA)))) %>% 
  #remove nepal and oman long monarchies cause they wack - maybe include it with it in the appendix
  #filter(gwf_duration < 100) %>% 
  mutate(cowcode = ifelse(cowcode == 816 & year >= 1976, 818, cowcode)) %>% 
  filter(gwf_regime %in% c("Military", "Monarchy", "Party", "Personal")) %>% 
  left_join(d3, by = c("cowcode", "year")) %>% 
  mutate(lgmilex_cap = log( milex_2000/tpop)) %>% 
  mutate(lgmilex_cap = ifelse(lgmilex_cap == -Inf, 0, lgmilex_cap)) %>% 
  select(-version, -gwf_nonautocracy) %>% 
  mutate(lgpec = log(pec), lgupop = log(upop)) %>% 
  mutate(lgupop = ifelse(lgupop == -Inf, 0, lgupop)) %>% 
  mutate(lgpec = ifelse(lgpec == -Inf, 0, lgpec)) %>% 
  write_csv("data/panel.csv")




